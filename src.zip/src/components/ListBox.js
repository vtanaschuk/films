import { useState } from "react";
import Movie from "./Movie";
import MoviesList from "./MoviesList";
export default function ListBox({ movies }) {
  const [isOpen1, setIsOpen1] = useState(true);

  return (
    <div className="box">
      <button
        className="btn-toggle"
        onClick={() => setIsOpen1((open) => !open)}
      >
        {isOpen1 ? "–" : "+"}
      </button>
      {isOpen1 && <MoviesList movies={movies} />}
      <img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.ivi.ru%2Fwatch%2F184041&psig=AOvVaw0CCx4S5TNnqraDikn0EXj0&ust=1710519345461000&source=images&cd=vfe&opi=89978449&ved=0CBMQjRxqFwoTCIiy06GT9IQDFQAAAAAdAAAAABAE"></img>
    </div>
  );
}
